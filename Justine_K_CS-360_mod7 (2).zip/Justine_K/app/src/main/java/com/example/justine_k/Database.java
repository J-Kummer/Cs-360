package com.example.justine_k;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AppDatabase.db";
    private static final int DATABASE_VERSION = 3;

    //users table
    public static final String TABLE_USERS = "user";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    // inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String ITEM_ID = "item_id";
    public static final String ITEM_NAME = "name";
    public static final String ITEM_QUANTITY = "quantity";
    public static final String ITEM_USER_ID = "user_id"; // ✅ FIXED NAME

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
//creates database on installation
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE, " +
                        PASSWORD + " TEXT)"
        );

        db.execSQL(
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ITEM_NAME + " TEXT, " +
                        ITEM_QUANTITY + " INTEGER, " +
                        ITEM_USER_ID + " INTEGER)"
        );
    }
//upgrade to prevent crashes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);

        onCreate(db);

    }

    //adds new users into the database

    public boolean insertUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put(USERNAME, username);

        cv.put(PASSWORD, password);

        return db.insert(TABLE_USERS, null, cv) != -1;
    }
    //checks users
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }
    //gets the user data from table
    public int getUserId(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT " + USER_ID +
                        " FROM " + TABLE_USERS +
                        " WHERE " + USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password}
        );

        int id = -1;

        if (c.moveToFirst()) {
            id = c.getInt(0);
        }

        c.close();
        return id;
    }

    // adds item to the inventory

    public void insertItem(String name, int qty, int userId) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put(ITEM_NAME, name);

        cv.put(ITEM_QUANTITY, qty);

        cv.put(ITEM_USER_ID, userId);

        db.insert(TABLE_INVENTORY, null, cv);
    }
    //gets the items by user
    public Cursor getItemsByUser(int userId) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY +
                        " WHERE " + ITEM_USER_ID + "=?",
                new String[]{String.valueOf(userId)}
        );
    }
//updates the item quantity
    public void updateItem(int id, int qty) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(ITEM_QUANTITY, qty);

        db.update(TABLE_INVENTORY,
                cv,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
    }
//deletes item
    public void deleteItem(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_INVENTORY,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
    }
}