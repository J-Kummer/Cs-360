package com.example.justine_k;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Sms_Settings_Activity extends AppCompatActivity {

    EditText phoneInput;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    Switch smsSwitch;
    Button enterBtn;

    SharedPreferences prefs;

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_message);

        phoneInput = findViewById(R.id.editTextPhone);

        smsSwitch = findViewById(R.id.switch2);

        enterBtn = findViewById(R.id.button2);

        prefs = getSharedPreferences("SMS_PREF", MODE_PRIVATE);

        // restore saved values
        phoneInput.setText(prefs.getString("phone", ""));

        smsSwitch.setChecked(prefs.getBoolean("enabled", false));

        enterBtn.setOnClickListener(v -> saveSettingsAndContinue());

        checkPermission();
    }
    //saves sms preferences and then goes to the inventory
    private void saveSettingsAndContinue() {

        String phone = phoneInput.getText().toString().trim();

        boolean enabled = smsSwitch.isChecked();

        if (phone.isEmpty()) {
            Toast.makeText(this, "Enter phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("phone", phone);

        editor.putBoolean("enabled", enabled);

        editor.apply();

        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();


        Intent intent = new Intent(this, Inventory_Activity.class);

        int userId = getIntent().getIntExtra("USER_ID", -1);

        intent.putExtra("USER_ID", userId);

        startActivity(intent);
        finish();
    }

    //request permission for sms
    private void checkPermission() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }
}