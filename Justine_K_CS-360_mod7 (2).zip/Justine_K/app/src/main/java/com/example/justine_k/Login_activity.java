package com.example.justine_k;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login_activity extends AppCompatActivity {

    EditText usernameInput, passwordInput;

    Button loginButton, createAccountButton;

    CheckBox rememberMe;

    Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.login_activity);

        usernameInput = findViewById(R.id.editTextText);

        passwordInput = findViewById(R.id.editTextTextPassword);

        createAccountButton = findViewById(R.id.button3);

        loginButton = findViewById(R.id.buttonLogin);


        dbHelper = new Database(this);

        loginButton.setOnClickListener(v -> loginUser());

        createAccountButton.setOnClickListener(v -> createUser());
    }

    // create a user  account, stores it in the database

    private void createUser() {

        String username = usernameInput.getText().toString().trim();

        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();

            return;
        }

        boolean inserted = dbHelper.insertUser(username, password);

        if (inserted) {
            Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();

        } else {

            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }

    // login in user using username and password, checks it in the database
    private void loginUser() {

        String username = usernameInput.getText().toString().trim();

        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean valid = dbHelper.checkUser(username, password);

        if (!valid) {
            Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            return;
        }

        int userId = dbHelper.getUserId(username, password);

        if (userId == -1) {

            Toast.makeText(this, "Login error", Toast.LENGTH_SHORT).show();

            return;
        }

        // open sms before inventory_activity
        Intent smsIntent = new Intent(this, Sms_Settings_Activity.class);

        smsIntent.putExtra("USER_ID", userId);

        startActivity(smsIntent);


        finish();
    }
}