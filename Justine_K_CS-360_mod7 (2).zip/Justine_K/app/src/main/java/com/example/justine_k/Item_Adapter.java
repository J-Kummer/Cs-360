package com.example.justine_k;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Item_Adapter extends RecyclerView.Adapter<Item_Adapter.ViewHolder> {

    private final List<Item> itemList;
    private final Database db;
    private final Inventory_Activity activity;

    public Item_Adapter(List<Item> itemList, Database db, Inventory_Activity activity) {
        this.itemList = itemList;
        this.db = db;
        this.activity = activity;
    }

    // hold the references to UI elements for each row
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView name, qty;
        Button plus, minus, delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.itemName);

            qty = itemView.findViewById(R.id.itemQty);

            plus = itemView.findViewById(R.id.btnPlus);

            minus = itemView.findViewById(R.id.btnMinus);

            delete = itemView.findViewById(R.id.btnDelete);
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);

        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Item item = itemList.get(position);

        holder.name.setText(item.getName());
        holder.qty.setText(String.valueOf(item.getQuantity()));

        // adds item by one and updates database
        holder.plus.setOnClickListener(v -> {

            int pos = holder.getBindingAdapterPosition();

            if (pos == RecyclerView.NO_POSITION) return;

            Item current = itemList.get(pos);

            current.setQuantity(current.getQuantity() + 1);

            db.updateItem(current.getId(), current.getQuantity());

            notifyItemChanged(pos);
        });

        /* decreases item quantity by 1 and updates database,
        quantity wont go below zero */
        holder.minus.setOnClickListener(v -> {

            int pos = holder.getBindingAdapterPosition();

            if (pos == RecyclerView.NO_POSITION) return;

            Item current = itemList.get(pos);

            if (current.getQuantity() > 0) {

                current.setQuantity(current.getQuantity() - 1);
                db.updateItem(current.getId(), current.getQuantity());

                // low stock alert by sms if less than five
                if (current.getQuantity() <= 5) {
                    activity.sendLowStockSMS(
                            current.getName(),
                            current.getQuantity()
                    );
                }

                notifyItemChanged(pos);
            }
        });

        // delete item
        holder.delete.setOnClickListener(v -> {

            int pos = holder.getBindingAdapterPosition();

            if (pos == RecyclerView.NO_POSITION) return;

            Item current = itemList.get(pos);

            db.deleteItem(current.getId());

            itemList.remove(pos);

            notifyItemRemoved(pos);

            notifyItemRangeChanged(pos, itemList.size());
        });
    }


    @Override
    public int getItemCount() {
        return itemList.size();
    }
}