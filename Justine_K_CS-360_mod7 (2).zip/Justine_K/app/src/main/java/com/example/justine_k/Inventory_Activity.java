package com.example.justine_k;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class Inventory_Activity extends AppCompatActivity {

    RecyclerView recyclerView;
    Database db;
    Item_Adapter adapter;
    ArrayList<Item> itemList;

    FloatingActionButton addBtn;

    int userId;

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.list_activity);

        recyclerView = findViewById(R.id.recyclerView);

        addBtn = findViewById(R.id.addItem);

        db = new Database(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userId = getIntent().getIntExtra("USER_ID", -1);

        addBtn.setOnClickListener(v -> showAddItemDialog());

        requestSmsPermission();
        loadInventory();
    }

    // sms permission
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    // load inventory by user
    private void loadInventory() {

        itemList = new ArrayList<>();

        Cursor cursor = db.getItemsByUser(userId);

        if (cursor != null && cursor.moveToFirst()) {

            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("item_id"));

                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));

                int qty = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

                itemList.add(new Item(id, name, qty));

            } while (cursor.moveToNext());

            cursor.close();
        }

        adapter = new Item_Adapter(itemList, db, this);

        recyclerView.setAdapter(adapter);
    }

    //add item pop up, name and quantity
    private void showAddItemDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Add Item");

        LinearLayout layout = new LinearLayout(this);

        layout.setOrientation(LinearLayout.VERTICAL);

        layout.setPadding(40, 20, 40, 20);

        EditText nameInput = new EditText(this);

        nameInput.setHint("Item Name");

        EditText qtyInput = new EditText(this);

        qtyInput.setHint("Quantity");

        qtyInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        layout.addView(nameInput);

        layout.addView(qtyInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {

            String name = nameInput.getText().toString().trim();

            String qtyStr = qtyInput.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty = Integer.parseInt(qtyStr);

            db.insertItem(name, qty, userId);
            loadInventory();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // sms low stock alerts
    public void sendLowStockSMS(String item, int qty) {

        SharedPreferences prefs =
                getSharedPreferences("SMS_PREF", MODE_PRIVATE);

        boolean enabled = prefs.getBoolean("enabled", false);
        String phone = prefs.getString("phone", "");

        if (!enabled || phone.isEmpty()) return;

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {
            SmsManager sms = SmsManager.getDefault();
        //sends low stock warning and quantity
            sms.sendTextMessage(
                    phone,
                    null,
                    "LOW STOCK: " + item + " (" + qty + ")",
                    null,
                    null
            );
        //if sms fails to send
        } catch (Exception e) {
            Toast.makeText(this,
                    "SMS failed: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }
}