package com.example.justine_k;
public class Item {

    private final int id;
    private final String name;
    private int quantity;
    //creates an item with id, name, and quantity
    public Item(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }
//returns item id
    public int getId() {
        return id;
    }
//returns item name
    public String getName() {
        return name;
    }
//returns the current quantity
    public int getQuantity() {
        return quantity;
    }
//updates the quantity of item
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}